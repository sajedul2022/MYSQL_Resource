
<div style="padding-top: 10px; padding-bottom: 10px; padding-right: 15px;">
     <nav class="float-left navbar navbar-expand-md navbar-dark">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleMenu1">
    <span class="navbar-toggler-icon"></span>
    </button> 
	 <div class="btn-group-vertical btn-group-sm collapse navbar-collapse" id="collapsibleMenu1"  role="group" aria-label="Button Group">
	 <ul class="navbar-nav flex-column" style="width: 140px;">
      <li class="nav-item">
	 <a class="btn btn-primary" id="buttons" title="Page Two" href="#" role="button">About Us</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" id="buttons" title="The Birds" href="birds.php" role="button">The Birds</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" id="buttons" title="The Reserves" href="reserves.php" role="button">The Reserves</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" id="buttons" title="Page Five" href="join-2.php" role="button">Join 2 Tables</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" id="buttons" title="Page Five" href="join-3.php" role="button">Join 3 Tables</a>
	 </li>
	  <li class="nav-item">
	 <a class="btn btn-primary" id="buttons" title="Return to Home Page" href="index.php" role="button">Home Page</a>
	 </li>
	 </div>
    </nav>
	</div>