<!--The side menu column contains the vertical menu block-->
<ul>
<li><a href="page-2.php" title="Page two">Page 2</a></li>
<li><a href="page-3.php" title="Page three">Page 3</a></li>
<li><a href="page-4.php" title="Page four">Page 4</a></li>
<li><a href="page-5.php" title="Page five">Page 5</a></li>
<li><a href="index.php" title="Return to Home Page">Home Page</a></li>
</ul>
