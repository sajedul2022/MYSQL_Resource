vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Aug 2017 15:20:59 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|login.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|20 Aug 2017 15:20:59 -0000
vti_cacheddtm:TX|20 Aug 2017 15:20:59 -0000
vti_filesize:IR|249
vti_cachedlinkinfo:VX|H|login.php H|register-page.php H|index.php
vti_cachedsvcrellinks:VX|NHUS|includes/login.php NHUS|includes/register-page.php NHUS|includes/index.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
