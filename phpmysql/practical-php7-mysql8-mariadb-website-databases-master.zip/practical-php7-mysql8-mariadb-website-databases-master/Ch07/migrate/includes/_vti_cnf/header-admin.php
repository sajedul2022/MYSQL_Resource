vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2017 20:13:21 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|view_found_record.php admin-page.php search_address.php edit_address.php edit_record.php admin_view_users.php view_found_address.php search.php delete_record.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|19 Dec 2017 20:13:21 -0000
vti_cacheddtm:TX|19 Dec 2017 20:13:21 -0000
vti_filesize:IR|357
vti_cachedlinkinfo:VX|H|logout.php H|admin_view_users.php H|search.php H|search_address.php H|register-password.php
vti_cachedsvcrellinks:VX|NHUS|includes/logout.php NHUS|includes/admin_view_users.php NHUS|includes/search.php NHUS|includes/search_address.php NHUS|includes/register-password.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
