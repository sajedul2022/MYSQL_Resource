vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Dec 2017 12:14:16 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.php login.php view_found_record.php search_address.php edit_address.php edit_record.php page-5.php admin_view_users.php view_found_address.php page-3.php page-4.php search.php delete_record.php page-2.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|07 Dec 2017 12:14:16 -0000
vti_cacheddtm:TX|07 Dec 2017 12:14:16 -0000
vti_filesize:IR|128
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
