vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Aug 2017 16:37:50 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.php login.php view_found_record.php admin-page.php search_address.php edit_record.php members-page.php page-5.php admin_view_users.php page-3.php page-4.php view_found_address.php search.php delete_record.php page-2.php safer-register-page.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|17 Aug 2017 16:37:50 -0000
vti_cacheddtm:TX|17 Aug 2017 16:37:50 -0000
vti_filesize:IR|315
vti_cachedlinkinfo:VX|H|http://www.colycomputerhelp.co.uk/ H|http://www.littleoceanwaves.com H|http://jigsaw.w3.org/css-validator/ H|http://validator.w3.org/
vti_cachedsvcrellinks:VX|NHHS|http://www.colycomputerhelp.co.uk/ NHHS|http://www.littleoceanwaves.com NHHS|http://jigsaw.w3.org/css-validator/ NHHS|http://validator.w3.org/
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
