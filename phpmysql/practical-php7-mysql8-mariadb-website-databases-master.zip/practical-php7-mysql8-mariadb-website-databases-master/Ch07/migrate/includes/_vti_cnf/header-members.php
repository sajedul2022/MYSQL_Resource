vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Sep 2017 17:40:15 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|members-page.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|07 Sep 2017 17:40:15 -0000
vti_cacheddtm:TX|07 Sep 2017 17:40:15 -0000
vti_filesize:IR|202
vti_cachedlinkinfo:VX|H|logout.php H|register-password.php
vti_cachedsvcrellinks:VX|NHUS|includes/logout.php NHUS|includes/register-password.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
