vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Aug 2017 16:24:57 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|login.php view_found_record.php register-thanks.php index.php admin-page.php search_address.php edit_address.php edit_record.php members-page.php page-5.php admin_view_users.php view_found_address.php page-3.php page-4.php search.php delete_record.php page-2.php safer-register-page.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|17 Aug 2017 16:24:57 -0000
vti_cacheddtm:TX|17 Aug 2017 16:24:57 -0000
vti_filesize:IR|387
vti_cachedlinkinfo:VX|H|page-2.php H|page-3.php H|page-4.php H|page-5.php H|index.php
vti_cachedsvcrellinks:VX|NHUS|includes/page-2.php NHUS|includes/page-3.php NHUS|includes/page-4.php NHUS|includes/page-5.php NHUS|includes/index.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
