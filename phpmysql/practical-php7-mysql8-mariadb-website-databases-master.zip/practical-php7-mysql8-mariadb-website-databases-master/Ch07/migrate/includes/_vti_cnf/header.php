vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Dec 2017 18:19:35 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.php page-5.php page-3.php page-4.php page-2.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|26 Dec 2017 18:19:35 -0000
vti_cacheddtm:TX|26 Dec 2017 18:19:35 -0000
vti_filesize:IR|199
vti_cachedlinkinfo:VX|H|login.php H|safer-register-page.php
vti_cachedsvcrellinks:VX|NHUS|includes/login.php NHUS|includes/safer-register-page.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
