vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 Oct 2017 18:16:10 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|login.php
vti_author:SR|USERX-893NME34B\\Janice
vti_modifiedby:SR|USERX-893NME34B\\Janice
vti_timecreated:TR|29 Oct 2017 18:16:10 -0000
vti_cacheddtm:TX|29 Oct 2017 18:16:10 -0000
vti_filesize:IR|668
vti_cachedlinkinfo:VX|A|login.php
vti_cachedsvcrellinks:VX|NAUS|includes/login.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
