<p>Copyright &copy; Adrian West & Steve Prettyman 2017  Designed by
<a href="http://www.colycomputerhelp.co.uk/">Adrian West </a> and 
<a href=http://www.littleoceanwaves.com>Steve Prettyman </a>  Valid
<a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp;
<a href="http://validator.w3.org/">HTML5</a></p>