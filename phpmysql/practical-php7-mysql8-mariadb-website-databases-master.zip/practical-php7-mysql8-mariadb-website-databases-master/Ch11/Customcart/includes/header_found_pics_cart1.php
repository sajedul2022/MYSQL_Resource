<div class="col-sm-2" >
<img id="logo" class="img-fluid" style="padding-top: 5px; height="170" src="images/dove-1.png" alt="dove"> 
</div>
<div class="col-sm-8" style="color :white; padding-top: 5%;">
 <div class="h1 mb-2 font-bold text-left" >The Dove Gallery</div>
 <p class='lead text-center'>Affordable Original Paintings</p>
</div>
<div class="col-sm-2" style="padding-top: 10px; padding-bottom: 10px;">
     <nav>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="cart.php" role="button">View Cart</a>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="index.php" role="button">Home Page</a>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="Logout.php" role="button">Logout</a>
    </nav>
	</div>