<div style="padding-top: 10px; padding-bottom: 10px;">
     <nav>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="#" role="button">About Us</a>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="#" role="button">FAQs</a>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="#" role="button">Contact Us</a>
	 <a class="btn btn-primary btn-sm float-right" style="background:#559a55; border: 5px outset #559a55; width:160px;" href="index.php" role="button">Home Page</a>
    </nav>
	</div>