<!doctype html>
<html lang="en">
<head>
<title>Home page</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="transparent.css">
<style type="text/css">
#content h2 { margin-left:0; }
#content h3 { margin-left:200px; }
</style>
</head>
<body>
<div id="container">
<header>
<?php include('includes/header_thanks.inc'); ?>
</header>
	<div id="content"><!--Start of the thank you page content-->
<div id="rightcol">
<nav>
<?php include('includes/menu.inc'); ?>
</nav>
</div>

<div id="midcol">
<h2>Thank you for registering</h2>
<h3>You will now be able to login, search for, and view the paintings.</h3>

</div><br class="clear">
	<!--End of the thankyou page content-->
<footer>
<?php include ('includes/footer.inc'); ?>
</footer>
</div></div>

</body>
</html>