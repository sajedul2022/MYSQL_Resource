<div>
<h3>This is the information column</h3>
	<p>Web design by <br>A W West and<br>Steve Prettyman</p>
</div>