
<li><a href="register-page.php">Register</a></li>
<li><a href="register-view_users-page.php">View Users</a></li>
<li><a href="register-password.php">New Password</a></li>
