<div class="col-sm-2">
<img class="img-fluid float-left" src="logo.jpg" alt="Logo"> 
</div>
<div class="col-sm-8">
 <h1 class="font-bold">This is the header</h1>
</div>
    