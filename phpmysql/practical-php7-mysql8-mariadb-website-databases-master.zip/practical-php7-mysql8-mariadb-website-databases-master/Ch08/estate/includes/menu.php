


<div style="padding-top: 10px; padding-bottom: 10px; padding-right: 15px;">
     <nav class="float-right navbar navbar-expand-md navbar-dark">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleMenu1">
    <span class="navbar-toggler-icon"></span>
  </button>
	 <div class="btn-group-vertical btn-group-sm collapse navbar-collapse" id="collapsibleMenu1"  role="group" aria-label="Button Group">
	 <ul class="navbar-nav flex-column" style="width: 140px;">
      <li class="nav-item">
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">About Us</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">FAQs</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="contact.php" role="button">Contact Us</a>
	 </li>
	 <li class="nav-item">
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="index.php" role="button">Home Page</a>
	 </li>
	 </ul>
	 </div>
    </nav>
	</div>