<div class="jumbotron text-center row mx-auto" id="includeheader"> 
<div class="col-sm-10">
<h1 class="text-left"><strong>Devon Real Estate</strong></h1>
<h2 class="text-center">Try our award winning service</h2>
</div>
  <nav class="col-sm-2">
	 <div class="btn-group-vertical btn-group-sm" role="group" style="width: 140px; margin-top:-25px;" aria-label="Button Group">
  <button type="button" class="btn btn-secondary" id="buttons" onclick="location.href = 'advert_houses.php'" >View Houses</button>
  <button type="button" class="btn btn-secondary" id="buttons" onclick="location.href = 'advert_search.php'">Search</button>
   <button type="button" class="btn btn-secondary" id="buttons" onclick="location.href = 'index.php'">Home Page</button>
</div>
    </nav>
</div>
<img id="rosette1" alt="Rosette" title="Rosette" height="127" 
src="images/rosette-128.png" width="128">