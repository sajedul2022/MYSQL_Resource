<div style="padding-top: 10px; padding-bottom: 10px; padding-right: 15px;">
     <nav class="float-center navbar navbar-expand-md navbar-dark">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleMenu1">
    <span class="navbar-toggler-icon"></span>
  </button>
	 <div class="btn-group btn-group-sm collapse navbar-collapse" id="collapsibleMenu1"  role="group" aria-label="Button Group">
	 <div class="navbar-nav flex-column" style="width: 140px;">
      
	 <a class="btn btn-primary nav-item" style="background:#559a55; border: 5px outset #559a55;" href="advert.php" role="button">Another House?</a>
	
	 
	 <a class="btn btn-primary nav-item" style="background:#559a55; border: 5px outset #559a55;" href="index.php" role="button">Home Page</a>
	 
	 </div>
	 </div>
    </nav>
	</div>