<h3>This is the information column</h3>
<p>Information area</p>

