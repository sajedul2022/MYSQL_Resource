<div class="col-sm-2">
<img class="img-fluid float-left" src="logo.jpg" alt="Logo"> 
</div>
<div class="col-sm-8">
 <h1 class="blue-text mb-4 font-bold">Header Goes Here</h1>
 </div>
     <nav class="col-sm-2">
	 <div class="btn-group-vertical btn-group-sm" role="group" aria-label="Button Group">
  <button type="button" class="btn btn-secondary" onclick="location.href = 'register-password.php'" >Erase Entries</button>
  <button type="button" class="btn btn-secondary" onclick="location.href = 'index.php'">Cancel</button>
</div>
    </nav>