    <li class="nav-item">
          <a class="nav-link active" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="page-2.php">Page 2</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="page-3.php">Page 3</a>
        </li>
		 <li class="nav-item">
          <a class="nav-link" href="page-4.php">Page 4</a>
        </li>
		 <li class="nav-item">
          <a class="nav-link" href="page-5.php">Page 5</a>
        </li>