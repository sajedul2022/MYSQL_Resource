
<h3 class="text-center">Payment Methods</h3>
	<img alt="Pay by PayPal or Credit card" title="Pay by PayPal or Credit card"src="images/vertical_solution_PP.png">

